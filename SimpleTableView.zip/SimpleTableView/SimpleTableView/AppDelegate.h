//
//  AppDelegate.h
//  SimpleTableView
//
//  Created by dry on 2018/3/1.
//  Copyright © 2018年 MorrisMeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

