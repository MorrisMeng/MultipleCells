//
//  ImageCell.m
//  SimpleTableView
//
//  Created by dry on 2018/3/1.
//  Copyright © 2018年 MorrisMeng. All rights reserved.
//

#import "ImageCell.h"

@implementation ImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.imgView.frame = CGRectMake(16, 2, self.frame.size.height-4, self.frame.size.height-4);
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        self.imgView = [[UIImageView alloc] init];
        self.imgView.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:self.imgView];
        
    }
    return self;
}

@end
