//
//  TitleImageCell.m
//  SimpleTableView
//
//  Created by dry on 2018/3/1.
//  Copyright © 2018年 MorrisMeng. All rights reserved.
//

#import "TitleImageCell.h"

@implementation TitleImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.imgView.frame = CGRectMake(16, 2, self.frame.size.height-4, self.frame.size.height-4);
    
    self.titleLabel.frame = CGRectMake(self.imgView.frame.origin.x+self.imgView.frame.size.width+16,
                                       0,
                                       self.frame.size.width*0.5,
                                       self.frame.size.height);
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier])
    {
        self.imgView = [[UIImageView alloc] init];
        self.imgView.backgroundColor = [UIColor brownColor];
        [self.contentView addSubview:self.imgView];

        self.titleLabel = [[UILabel alloc] init];
        self.titleLabel.font = [UIFont systemFontOfSize:14.0];
        [self.contentView addSubview:self.titleLabel];
    }
    return self;
}


@end
