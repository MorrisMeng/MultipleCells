//
//  ViewController.m
//  SimpleTableView
//
//  Created by dry on 2018/3/1.
//  Copyright © 2018年 MorrisMeng. All rights reserved.
//

#import "ViewController.h"
#import "TitleCell.h"
#import "ImageCell.h"
#import "TitleImageCell.h"
#import "CellModel.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /*
     场景：有三种类型的cell
     第一种，只有title
     第二种，只有image
     第三种，有标题和图标
     
     一般默认的实现方案：
     不同的的indexPath.row返回不同的cell，这种需要判断是哪一个cell，返回对应类型的cell，如果cell类型多的话，各种判断
     */
    
    [self setUpUi];
    
    [self initData];
}

- (void)setUpUi {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
}

- (void)initData
{
    [self.dataSource removeAllObjects];
    for (int i = 0; i<10; i++)
    {
        CellModel *model  = [[CellModel alloc] init];
        model.title = [NSString stringWithFormat:@"第%ld行",(long)i];
        model.image = [UIImage imageNamed:@"QQ"];
        
        [self.dataSource addObject:model];
    }
    [self.tableView reloadData];
}


#pragma mark - delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellModel *model = self.dataSource[indexPath.row];
    
    //只有title
    if (indexPath.row < 4) {
        NSString *cellID = @"ViewController_TitleCell";
        TitleCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[TitleCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.titleLabel.text = model.title;
        
        return cell;
    }
    //只有图标
    else if (indexPath.row == 4 || indexPath.row == 5) {
        NSString *cellID = @"ViewController_ImageCell";
        ImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[ImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.imgView.image = model.image;

        return cell;
    }
    //既有图标，又有title
    else {
        NSString *cellID = @"ViewController_TitleImageCell";
        TitleImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[TitleImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.titleLabel.text = model.title;
        cell.imgView.image = model.image;
        
        return cell;
    }
    return nil;
}






- (NSMutableArray *)dataSource {
    if (!_dataSource) {
        _dataSource = [[NSMutableArray alloc] init];
    }
    return _dataSource;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
