## 一般思路

判断不同的行返回各自不同的cell就行了，这种思路很容易理解，适用于简单的tableView。但是会导致返回cell的方法里各种判断。

```
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellModel *model = self.dataSource[indexPath.row];
    
    //只有title
    if (indexPath.row < 4) {
        NSString *cellID = @"ViewController_TitleCell";
        TitleCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[TitleCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.titleLabel.text = model.title;
        
        return cell;
    }
    //只有图标
    else if (indexPath.row == 4 || indexPath.row == 5) {
        NSString *cellID = @"ViewController_ImageCell";
        ImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[ImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.imgView.image = model.image;

        return cell;
    }
    //既有图标，又有title
    else {
        NSString *cellID = @"ViewController_TitleImageCell";
        TitleImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
        if (!cell) {
            cell = [[TitleImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        }
        cell.titleLabel.text = model.title;
        cell.imgView.image = model.image;
        
        return cell;
    }
    return nil;
}
```


