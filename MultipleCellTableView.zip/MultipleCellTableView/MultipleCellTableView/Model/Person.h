//
//  Person.h
//  MultipleCellTableView
//
//  Created by Dry on 2018/3/2.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Person : NSObject

@property (nonatomic, strong, nonnull) NSString *cellReusedId;//对应cell的复用标识

@property (nonatomic, strong, nullable) NSString *name;
@property (nonatomic, strong, nullable) UIImage *avatar;

@end
