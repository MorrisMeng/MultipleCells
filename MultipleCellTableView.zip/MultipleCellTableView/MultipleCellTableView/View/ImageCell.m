//
//  ImageCell.m
//  MultipleCellTableView
//
//  Created by Dry on 2018/3/2.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import "ImageCell.h"

@implementation ImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _heardImgView.frame = CGRectMake(10, 2, self.frame.size.height-4, self.frame.size.height-4);
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.heardImgView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.heardImgView];
    }
    return self;
}

- (void)setPerson:(Person *)p {
    [super setPerson:p];
    _heardImgView.image = p.avatar;
}

@end
