//
//  TextImageCell.h
//  MultipleCellTableView
//
//  Created by Dry on 2018/3/2.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import "BaseCell.h"

@interface TextImageCell : BaseCell

@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UIImageView *heardImgView;

@end
