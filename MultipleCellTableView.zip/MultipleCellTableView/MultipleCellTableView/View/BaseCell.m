//
//  BaseCell.m
//  MultipleCellTableView
//
//  Created by Dry on 2018/3/2.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import "BaseCell.h"

@implementation BaseCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setPerson:(Person *)p {
    
}

@end
