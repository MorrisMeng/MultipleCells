//
//  TextImageCell.m
//  MultipleCellTableView
//
//  Created by Dry on 2018/3/2.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import "TextImageCell.h"

@implementation TextImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    _heardImgView.frame = CGRectMake(10, 2, self.frame.size.height-4, self.frame.size.height-4);
    _nameLabel.frame = CGRectMake(_heardImgView.frame.origin.x+_heardImgView.frame.size.width+10, 10, 200, 40);
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.heardImgView = [[UIImageView alloc] init];
        self.nameLabel = [[UILabel alloc] init];
        
        [self.contentView addSubview:self.heardImgView];
        [self.contentView addSubview:self.nameLabel];
    }
    return self;
}


- (void)setPerson:(Person *)p {
    [super setPerson:p];
    _nameLabel.text = p.name;
    _heardImgView.image = p.avatar;
}



@end
