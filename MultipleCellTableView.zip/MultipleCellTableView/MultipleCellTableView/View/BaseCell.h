//
//  BaseCell.h
//  MultipleCellTableView
//
//  Created by Dry on 2018/3/2.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"

@interface BaseCell : UITableViewCell

- (void)setPerson:(Person *)p;

@end
