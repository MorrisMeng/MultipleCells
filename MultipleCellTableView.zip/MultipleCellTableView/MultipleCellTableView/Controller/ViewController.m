//
//  ViewController.m
//  MultipleCellTableView
//
//  Created by Dry on 2018/3/2.
//  Copyright © 2018年 Apple Inc. All rights reserved.
//

#import "ViewController.h"
#import "TextCell.h"
#import "ImageCell.h"
#import "TextImageCell.h"
#import "Person.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /*
     思路：
     1、不同类型的cell继承BaseCell实现多态赋值
     2、在处理model数据的时候就把cell的cellReusedId处理好
     3、cell的类名作复用id
     4、直接从数据源中取对应的cellReusedId，拿到对应类型的cell
     */
    
    //添加tableView
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    
    //注册cell
    [self.tableView registerClass:[TextCell class] forCellReuseIdentifier:NSStringFromClass([TextCell class])];
    [self.tableView registerClass:[ImageCell class] forCellReuseIdentifier:NSStringFromClass([ImageCell class])];
    [self.tableView registerClass:[TextImageCell class] forCellReuseIdentifier:NSStringFromClass([TextImageCell class])];
    
    //处理数据
    [self.dataSource removeAllObjects];
    
    Person *p1 = [[Person alloc] init];
    p1.cellReusedId = NSStringFromClass([TextCell class]);
    p1.name = @"Peter";
    [self.dataSource addObject:p1];

    Person *p2 = [[Person alloc] init];
    p2.cellReusedId = NSStringFromClass([ImageCell class]);
    p2.avatar = [UIImage imageNamed:@"10112726"];
    [self.dataSource addObject:p2];

    Person *p3 = [[Person alloc] init];
    p3.cellReusedId = NSStringFromClass([TextImageCell class]);
    p3.name = @"James";
    p3.avatar = [UIImage imageNamed:@"11918635"];
    [self.dataSource addObject:p3];

    [self.tableView reloadData];
    
    /*
     最后总结：
     这种方式是将判断放在数据处理的时候，在处理model数据时就将该model对应的标识赋值给model自己。再刷列表的时候再用model的标识取找对应的cell。
     tableView的代理方法里面代码简洁了不少，但是还是需要判断，有几种类型的cell就需要判断几次，个人感觉还太多的判断还是不好。
     通过继承实现了多态。
     */
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //1、取出数据源
    Person *p = self.dataSource[indexPath.row];
    //2、根据不同的复用标识取出对应的cell
    BaseCell *cell = nil;
    cell = [tableView dequeueReusableCellWithIdentifier:p.cellReusedId];
    //3、给cell赋值
    [cell setPerson:p];
    
    return cell;
}

- (NSMutableArray *)dataSource {
    if (!_dataSource) {
        _dataSource = [[NSMutableArray alloc] init];
    }
    return _dataSource;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
